
const mongoose = require("mongoose");

const studentSchema = new mongoose.Schema({
  name: String,
  roll: String,
  course: String
});

module.exports = mongoose.model("Student", studentSchema);
